# Week 05 Lab: Recursion & Functions - Starter Code
# COMP2152 - Python Programming

print("=" * 60)
print("WEEK 05 LAB: RECURSION & FUNCTIONS")
print("=" * 60)

# ============================================================
# Question 1: Fibonacci Number (LeetCode #509)
# Concepts: Recursion, base case, recursive case
# ============================================================
print("\n" + "=" * 50)
print("Question 1: Fibonacci Number (#509)")
print("=" * 50)


def fib(n):
    """
    Calculate the nth Fibonacci number using recursion.

    F(0) = 0
    F(1) = 1
    F(n) = F(n-1) + F(n-2) for n > 1
    """
    # Base case 1
    if n == 0:
        return 0

    # Base case 2
    if n == 1:
        return 1

    # Recursive case
    return fib(n - 1) + fib(n - 2)


# Test cases for Fibonacci
print("Fibonacci Sequence (F(0) to F(10)):")
print("-" * 30)
for i in range(11):
    result = fib(i)
    print("F(" + str(i) + ") = " + str(result))

print("\nAdditional test cases:")
print("F(15) = " + str(fib(15)))
print("F(20) = " + str(fib(20)))


# ============================================================
# Question 2: FizzBuzz (LeetCode #412)
# Concepts: Functions, conditionals, list building
# ============================================================
print("\n" + "=" * 50)
print("Question 2: FizzBuzz (#412)")
print("=" * 50)


def fizz_buzz(n):
    """
    Generate FizzBuzz sequence from 1 to n.
    """
    result = []

    for i in range(1, n + 1):
        if i % 3 == 0 and i % 5 == 0:
            result.append("FizzBuzz")
        elif i % 3 == 0:
            result.append("Fizz")
        elif i % 5 == 0:
            result.append("Buzz")
        else:
            result.append(str(i))

    return result


# Test cases for FizzBuzz
print("\nTest Case 1: n = 3")
result = fizz_buzz(3)
print("Output: " + str(result))
print("Expected: ['1', '2', 'Fizz']")

print("\nTest Case 2: n = 5")
result = fizz_buzz(5)
print("Output: " + str(result))
print("Expected: ['1', '2', 'Fizz', '4', 'Buzz']")

print("\nTest Case 3: n = 15")
result = fizz_buzz(15)
print("Output: " + str(result))
print("Expected: ['1', '2', 'Fizz', '4', 'Buzz', 'Fizz', '7', '8', 'Fizz', 'Buzz', '11', 'Fizz', '13', '14', 'FizzBuzz']")

print("\nTest Case 4: n = 1")
result = fizz_buzz(1)
print("Output: " + str(result))
print("Expected: ['1']")


# ============================================================
# Question 3: Binary Search (LeetCode #704)
# Concepts: Divide & Conquer, Iterative and Recursive
# ============================================================
print("\n" + "=" * 50)
print("Question 3: Binary Search (#704)")
print("=" * 50)


# Part A: Iterative Solution
def binary_search_iterative(nums, target):
    """
    Search for target in sorted array using iteration.
    """
    left = 0
    right = len(nums) - 1

    while left <= right:
        mid = (left + right) // 2  # must be integer

        if nums[mid] == target:
            return mid
        elif target < nums[mid]:
            right = mid - 1
        else:
            left = mid + 1

    return -1


# Part B: Recursive Solution
def binary_search_recursive(nums, target, left, right):
    """
    Search for target in sorted array using recursion.
    """
    # Base case
    if left > right:
        return -1

    mid = (left + right) // 2

    if nums[mid] == target:
        return mid
    elif target < nums[mid]:
        return binary_search_recursive(nums, target, left, mid - 1)
    else:
        return binary_search_recursive(nums, target, mid + 1, right)


# Wrapper function for recursive solution
def search_recursive(nums, target):
    """Wrapper function to call recursive binary search."""
    if len(nums) == 0:
        return -1
    return binary_search_recursive(nums, target, 0, len(nums) - 1)


# Test cases for Binary Search
print("\n--- Part A: Iterative Binary Search ---")
test_cases = [
    ([-1, 0, 3, 5, 9, 12], 9),
    ([-1, 0, 3, 5, 9, 12], 2),
    ([1], 1),
    ([1, 2, 3, 4, 5], 1),
    ([1, 2, 3, 4, 5], 5),
    ([1, 2, 3, 4, 5], 3),
    ([], 5),
]

for nums, target in test_cases:
    result = binary_search_iterative(nums, target)
    print("nums=" + str(nums) + ", target=" + str(target) + " -> index: " + str(result))

print("\n--- Part B: Recursive Binary Search ---")
for nums, target in test_cases:
    result = search_recursive(nums, target)
    print("nums=" + str(nums) + ", target=" + str(target) + " -> index: " + str(result))


# ============================================================
# Verification: Both methods should give same results
# ============================================================
print("\n" + "=" * 50)
print("Verification: Both Methods Should Match")
print("=" * 50)

nums = [-1, 0, 3, 5, 9, 12]
print("Array: " + str(nums))
print("-" * 40)

for target in [-1, 0, 3, 5, 9, 12, 2, 100]:
    iter_result = binary_search_iterative(nums, target)
    rec_result = search_recursive(nums, target)
    match = "PASS" if iter_result == rec_result else "FAIL"
    print(
        "Target " + str(target).rjust(4)
        + ": Iterative=" + str(iter_result).rjust(2)
        + ", Recursive=" + str(rec_result).rjust(2)
        + " " + match
    )

print("\n" + "=" * 60)
print("COMPLETE THE TODO SECTIONS ABOVE!")
print("=" * 60)
